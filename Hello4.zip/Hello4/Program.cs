﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Hello4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Helo World .NET 4.0");
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
        }
    }
}
